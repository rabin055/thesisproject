#!/bin/bash

print_output "This module extracts firmware with all available extractors and checks if a root filesystem can be found."
print_output "As last resort EMBA will try to extract every available file multiple times."
