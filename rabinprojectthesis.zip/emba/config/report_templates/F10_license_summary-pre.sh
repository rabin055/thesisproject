#!/bin/bash

print_output "This module collects license details and creates a details on the identified binaries, versions and the corresponding license (if available). The license details are maintained in the configuration file config/bin_version_strings.cfg."
