#!/bin/bash

print_output "Extracts gpg compressed (not encrypted) firmware images. This technique is used by multiple Linksys/Belkin firmware images"
