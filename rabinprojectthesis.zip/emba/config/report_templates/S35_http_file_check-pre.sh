#!/bin/bash

print_output "This module tries to identify httpd-related files including Nginx, Apache, httpd, lighttpd, cherokee and php.ini files."
