#!/bin/bash

print_output "This module tries to identify the Linux kernel version and the init command line."
