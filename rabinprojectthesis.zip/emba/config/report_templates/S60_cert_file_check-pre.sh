#!/bin/bash

print_output "This module tries to identify certificate files and checks the validity of the identified certificates."
