#!/bin/bash

print_output "EMBA was able to identify the shown software components with ${ORANGE}license details${NC}. These details should be checked for license violations."
