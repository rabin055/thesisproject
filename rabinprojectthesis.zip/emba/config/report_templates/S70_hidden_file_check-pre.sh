#!/bin/bash

print_output "This module tries to identify hidden Linux files."
