#!/bin/bash

print_output "This module extracts AVM firmware images with Freetz-NG (see https://github.com/Freetz-NG/freetz-ng.git)"
