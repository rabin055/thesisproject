#!/bin/bash

print_output "This module extracts version and license details from the results of the user-mode emulation module (s115)."
