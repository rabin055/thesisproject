#!/bin/bash

print_output "This module builds and emulates Linux firmware - this module is based on the great work of firmadyne"
print_output "Check out the original firmadyne project at https://github.com/firmadyne"
print_output "${MAGENTA}Warning:${NC} This module changes your network configuration and it could happen that your system looses network connectivity."
