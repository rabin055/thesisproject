#!/bin/bash

print_output "This module tries to identify ssh-related files and analyses found sshd configuration files with sshdcc - https://github.com/sektioneins/sshdcc."
