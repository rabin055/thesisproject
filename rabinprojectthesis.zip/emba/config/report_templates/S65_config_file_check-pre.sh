#!/bin/bash

print_output "This module tries to identify different kind of configuration files."
