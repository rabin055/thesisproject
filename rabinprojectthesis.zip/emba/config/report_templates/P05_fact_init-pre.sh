#!/bin/bash

print_output "This module extracts zip, tar, tgz firmware images with patool."
