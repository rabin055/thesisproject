#!/bin/bash

print_output "This module extracts UBI filesystems via ubireader_extract_images and ubireader_extract_files."
