#!/bin/bash

print_output "This module tries to identify shell scripts and analyses them with shellcheck - https://www.shellcheck.net/."
