#!/bin/bash

print_output "This module extracts encrypted firmware images from EnGenius reported by @ryancdotorg"
print_output "See https://twitter.com/ryancdotorg/status/1473807312242442240 and https://gist.github.com/ryancdotorg/914f3ad05bfe0c359b79716f067eaa99 for further details."
print_ln
