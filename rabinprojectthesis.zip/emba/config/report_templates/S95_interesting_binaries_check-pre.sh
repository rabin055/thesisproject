#!/bin/bash

print_output "This modules searches for interesting binaries like gcc or gdb. Additionally it also searches binaries that could be useful for post exploitation tasks like wget or ftp."

