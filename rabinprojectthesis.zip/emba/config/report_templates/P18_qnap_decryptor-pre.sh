#!/bin/bash

print_output "This module extracts encrypted firmware images from QNAP as shown here: https://github.com/max-boehm/qnap-utils"
