#!/bin/bash

print_output "This module shows several details of a Uboot image."
