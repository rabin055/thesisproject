#!/bin/bash

print_output "This module tries to identify the used operating system via simple counting of different keywords and doing some basic heuristics."
