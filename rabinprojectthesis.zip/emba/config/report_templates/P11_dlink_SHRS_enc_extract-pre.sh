#!/bin/bash

print_output "This module extracts encrypted firmware images from D-Link (See https://github.com/0xricksanchez/dlink-decrypt)"
