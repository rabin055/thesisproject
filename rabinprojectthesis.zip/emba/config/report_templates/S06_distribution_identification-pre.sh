#!/bin/bash

print_output "This module tries to identify the main Linux system (e.g. Kali Linux, Debian, Fedora, ...)"
