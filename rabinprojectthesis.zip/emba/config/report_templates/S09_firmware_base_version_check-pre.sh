#!/bin/bash

print_output "This module extracts version and license details from the firmware files."
print_output "On Linux based systems all binaries are analysed for version details."
print_output "On Non Linux systems all files are analysed for version details."
