#!/bin/bash

print_output "This module mounts and extracts ext2/3 images (currently binwalk destroys the permissions and the symlinks)."
