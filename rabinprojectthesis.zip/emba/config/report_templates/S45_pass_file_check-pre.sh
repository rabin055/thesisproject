#!/bin/bash

print_output "This module tries to identify password related files and analyses found password files for hashes, users and other configuration weaknesses."
